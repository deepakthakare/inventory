<?php
$config['sold_as'] = array('Kg', 'Pisces', 'Ton', 'Unit');
$config['tax_rate'] = array('5', '12', '18', '28');
$config['shipping'] = array('Standard UK Delivery (3-5 Days)' => '3.95', 'Next Working Day' => '5.95', 'Europe Zone 1 Standard (5-10 Working Days)' => '11.95', 'Europe Zone 1 DHL Express (1-3 Working Days)' => '27.95');
